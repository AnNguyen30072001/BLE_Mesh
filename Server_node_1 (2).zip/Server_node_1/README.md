| Supported Targets | ESP32 |
| ----------------- | ----- |

ESP BLE Mesh Vendor Server Example
==================================

For description of this example please refer to [ESP BLE Mesh Vendor Client Example](../vendor_client/README.md)
